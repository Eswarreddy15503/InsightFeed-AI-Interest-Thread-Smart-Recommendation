import React, { useState, useEffect } from 'react';
import { Reel, TechReel, RecommendationResponse, WatchFeedbackPayload } from './types';
import { ReelCard } from './components/ReelCard';
import { InferenceOutput } from './components/InferenceOutput';
import { VideoModal } from './components/VideoModal';
import { Header } from './components/Header';
import { INITIAL_8_DEMO_REELS, DAILY_TECH_REELS_POOL } from './data/demoReels';
import { runClientRecommendation } from './services/recommenderService';

export default function App() {
  const [watchHistory, setWatchHistory] = useState<Reel[]>(() => {
    return JSON.parse(JSON.stringify(INITIAL_8_DEMO_REELS));
  });
  const [selectedReelIds, setSelectedReelIds] = useState<string[]>(() => {
    return INITIAL_8_DEMO_REELS.map((r) => r.id);
  });
  const [watchedIds, setWatchedIds] = useState<string[]>([]);
  const [selectedDay, setSelectedDay] = useState<string>('today');
  
  const [isInferring, setIsInferring] = useState<boolean>(false);
  const [isResetting, setIsResetting] = useState<boolean>(false);
  
  const [inferenceResult, setInferenceResult] = useState<RecommendationResponse | null>(null);
  const [activeModalReel, setActiveModalReel] = useState<TechReel | null>(null);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [statusNotification, setStatusNotification] = useState<string | null>(null);

  // Reset history to initial 8 demo reels
  const handleResetHistory = () => {
    setIsResetting(true);
    setTimeout(() => {
      const freshHistory = JSON.parse(JSON.stringify(INITIAL_8_DEMO_REELS));
      setWatchHistory(freshHistory);
      setSelectedReelIds(freshHistory.map((r: Reel) => r.id));
      setWatchedIds([]);
      setInferenceResult(null);
      setIsResetting(false);
      showNotification('Watch history reset to initial 8 demo Reels.');
    }, 200);
  };

  const handleToggleSelect = (id: string) => {
    setSelectedReelIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    setSelectedReelIds(watchHistory.map((r) => r.id));
  };

  const handleDeselectAll = () => {
    setSelectedReelIds([]);
  };

  const handleQuickToggleEngagement = (
    id: string,
    newEngagement: 'liked' | 'skipped' | 'none'
  ) => {
    setWatchHistory((prev) =>
      prev.map((r) => {
        if (r.id === id) {
          const watchTime =
            newEngagement === 'skipped'
              ? 0.2
              : newEngagement === 'liked'
              ? 0.95
              : r.watch_time_percentage;
          return {
            ...r,
            engagement: newEngagement,
            watch_time_percentage: watchTime,
          };
        }
        return r;
      })
    );
  };

  // Run Client-Side Recommendation (Find my thread)
  const handleFindMyThread = () => {
    if (watchHistory.length === 0) return;

    setIsInferring(true);
    
    // Simulate brief 500ms neural category mapping animation for realistic student UX
    setTimeout(() => {
      try {
        const result = runClientRecommendation(
          watchHistory,
          selectedReelIds,
          watchedIds,
          selectedDay
        );
        setInferenceResult(result);
      } catch (err) {
        console.error('Client inference error:', err);
      } finally {
        setIsInferring(false);
      }
    }, 500);
  };

  const handleOpenWatchModal = (reel?: TechReel) => {
    if (reel) {
      setActiveModalReel(reel);
    } else if (inferenceResult?.recommended_reel) {
      setActiveModalReel(inferenceResult.recommended_reel);
    } else {
      const cat = inferenceResult?.CATEGORY;
      const found = DAILY_TECH_REELS_POOL.find((r) => r.category === cat) || DAILY_TECH_REELS_POOL[0];
      setActiveModalReel(found);
    }
    setIsModalOpen(true);
  };

  const handleFeedbackSubmitted = (feedback: WatchFeedbackPayload) => {
    // 1. Record watched id so future threads don't repeat it
    if (!watchedIds.includes(feedback.reel_id)) {
      setWatchedIds((prev) => [...prev, feedback.reel_id]);
    }

    // 2. Append new watched reel to history state
    const newEntry: Reel = {
      id: feedback.reel_id,
      title: feedback.reel_title,
      category: (feedback.category as any) || 'Tech-Explainer',
      tags: [feedback.category.toLowerCase(), 'educational', 'deep-dive'],
      watch_time_percentage: feedback.watch_percentage,
      engagement: feedback.skipped ? 'skipped' : feedback.liked ? 'liked' : feedback.completed ? 'saved' : 'none',
      duration_seconds: feedback.duration_seconds,
      replays: feedback.replays || 0,
      thumbnail_description: `Watched educational tech reel in ${feedback.category}.`
    };

    setWatchHistory((prev) => {
      const existingIdx = prev.findIndex((r) => r.id === feedback.reel_id);
      if (existingIdx >= 0) {
        const copy = [...prev];
        copy[existingIdx] = newEntry;
        return copy;
      }
      return [...prev, newEntry];
    });

    // Also auto-select the new history entry
    setSelectedReelIds((prev) => Array.from(new Set([...prev, feedback.reel_id])));

    showNotification(
      `Feedback recorded for "${feedback.reel_title}". History updated with fresh telemetry!`
    );
  };

  const showNotification = (msg: string) => {
    setStatusNotification(msg);
    setTimeout(() => {
      setStatusNotification(null);
    }, 4000);
  };

  return (
    <div className="min-h-screen bg-[#0d1117] text-[#f0f6fc] p-4 sm:p-8 flex flex-col items-center">
      {/* Toast Notification */}
      {statusNotification && (
        <div className="fixed top-4 right-4 z-50 bg-[#161b22] border border-emerald-500/40 text-emerald-300 px-4 py-2.5 rounded-lg shadow-xl text-xs flex items-center gap-2 animate-fade-in">
          <i className="fa-solid fa-circle-check text-emerald-400"></i>
          <span>{statusNotification}</span>
        </div>
      )}

      {/* Header with Title, CS301 Tag & Daily Feed Switcher */}
      <Header
        selectedDay={selectedDay}
        onSelectDay={setSelectedDay}
        onResetHistory={handleResetHistory}
        isResetting={isResetting}
      />

      {/* Main 2-Column Dashboard */}
      <main className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        {/* LEFT COLUMN: Student Watch History (Trap Data) */}
        <section className="glass-panel p-6 flex flex-col">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-2 pb-2 border-b border-white/5">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <i className="fa-solid fa-clock-rotate-left text-[#58a6ff]"></i>
              Student Watch History (Trap Data)
            </h2>
            <div className="flex items-center gap-2 text-xs">
              <button
                id="btn-select-all"
                onClick={handleSelectAll}
                className="text-[#58a6ff] hover:underline font-medium"
              >
                Select All
              </button>
              <span className="text-gray-600">&bull;</span>
              <button
                id="btn-deselect-all"
                onClick={handleDeselectAll}
                className="text-gray-400 hover:text-gray-200"
              >
                Clear
              </button>
            </div>
          </div>

          <p className="text-xs text-[#8b949e] mb-4 leading-relaxed">
            Loaded with addictive memes, lifestyle feeds, and hype which serve as cognitive traps. Select which Reels to feed into the inference engine:
          </p>

          {/* Reels List */}
          <div className="flex flex-col gap-3 max-h-[580px] overflow-y-auto pr-1">
            {watchHistory.length === 0 ? (
              <div className="text-center py-12 text-[#8b949e] text-xs">
                <p>No watch history available.</p>
              </div>
            ) : (
              watchHistory.map((reel) => (
                <ReelCard
                  key={reel.id}
                  reel={reel}
                  isSelected={selectedReelIds.includes(reel.id)}
                  onToggleSelect={handleToggleSelect}
                  onQuickToggleEngagement={handleQuickToggleEngagement}
                />
              ))
            )}
          </div>
        </section>

        {/* RIGHT COLUMN: Agent Inference Outputs */}
        <InferenceOutput
          isLoading={isInferring}
          result={inferenceResult}
          onOpenWatchModal={handleOpenWatchModal}
        />

        {/* BOTTOM ACTION PANEL: Find My Thread Button */}
        <div className="col-span-full flex flex-col items-center gap-3 my-4">
          <button
            id="btn-find-my-thread"
            onClick={handleFindMyThread}
            disabled={isInferring || selectedReelIds.length === 0}
            className={`px-8 py-3.5 rounded-full text-white font-semibold text-base shadow-lg transition transform flex items-center gap-3 ${
              selectedReelIds.length === 0
                ? 'bg-gray-800 text-gray-500 cursor-not-allowed opacity-50'
                : isInferring
                ? 'bg-gradient-to-r from-[#58a6ff] to-[#bc8cff] opacity-80 cursor-wait'
                : 'bg-gradient-to-r from-[#58a6ff] to-[#bc8cff] hover:opacity-95 hover:-translate-y-0.5 active:translate-y-0 shadow-[0_4px_20px_rgba(88,166,255,0.3)]'
            }`}
          >
            {isInferring ? (
              <>
                <i className="fa-solid fa-circle-notch fa-spin text-white"></i>
                <span>Analyzing Threads...</span>
              </>
            ) : (
              <>
                <i className="fa-solid fa-wand-magic-sparkles text-amber-300"></i>
                <span>Find my thread</span>
                <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full font-mono">
                  {selectedReelIds.length} Selected
                </span>
              </>
            )}
          </button>
          <p className="text-xs text-[#8b949e]">
            Analyzes watch %, likes, replays, and skipped signals to extract underlying CS concepts.
          </p>
        </div>
      </main>

      {/* Video Modal Player with Watch Progress, Like, Skip & Completion Tracking */}
      <VideoModal
        reel={activeModalReel}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onFeedbackSubmitted={handleFeedbackSubmitted}
      />

      {/* Footer */}
      <footer className="mt-auto pt-8 pb-4 text-center text-[#8b949e] text-xs w-full max-w-6xl border-t border-[#30363d]/30">
        <p>CS301: Introduction to Artificial Intelligence Project Proposal &bull; Team 4 &bull; Academic Prototype</p>
        <p className="text-[0.7rem] text-white/20 mt-1">
          Client-Side SPA Architecture &bull; Instant In-Memory AI Inference &bull; Real-time Feedback Loop
        </p>
      </footer>
    </div>
  );
}
