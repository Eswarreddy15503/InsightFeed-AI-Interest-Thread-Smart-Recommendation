export type ReelFormat = 'Meme' | 'Lifestyle' | 'Hardware-Spec' | 'Hype' | 'Career' | 'Tech-Explainer';

export type EngagementType = 'liked' | 'saved' | 'commented' | 'skipped' | 'none';

export interface Reel {
  id: string;
  title: string;
  category: ReelFormat;
  tags: string[];
  watch_time_percentage: number;
  engagement: EngagementType;
  duration_seconds: number;
  replays?: number;
  thumbnail_description: string;
  video_url?: string;
  channel_name?: string;
  views?: string;
}

export type TechCategory = 
  | 'Java' 
  | 'DSA' 
  | 'Hardware' 
  | 'HLD' 
  | 'Cybersecurity' 
  | 'Cloud' 
  | 'AI' 
  | 'Distributed Systems'
  | 'Compilers';

export type DifficultyLevel = 'Beginner' | 'Intermediate' | 'Advanced';
export type ConfidenceLevel = 'High' | 'Medium' | 'Low';

export interface TechReel {
  id: string;
  title: string;
  category: TechCategory;
  tags: string[];
  difficulty: DifficultyLevel;
  description: string;
  url: string;
  duration_seconds: number;
  day: string; // e.g. '2026-08-18' or 'today', 'tomorrow', 'day-3'
  code_snippet?: string;
  key_takeaway?: string;
  instructor?: string;
}

export interface RecommendationResponse {
  "CURRENT REEL": string;
  "INTEREST DETECTED": string;
  "WHY": string;
  "RECOMMENDED TECH REEL": string;
  "CATEGORY": TechCategory | string;
  "WHY THIS RECOMMENDATION": string;
  "DIFFICULTY": DifficultyLevel | string;
  "CONFIDENCE": ConfidenceLevel | string;
  recommendation_id?: string;
  recommended_reel?: TechReel;
  negative_signals_filtered?: string[];
  metrics_analyzed?: {
    total_reels: number;
    avg_watch_time: number;
    likes_count: number;
    skips_count: number;
    replays_count: number;
  };
}

export interface WatchFeedbackPayload {
  reel_id: string;
  reel_title: string;
  category: string;
  watch_percentage: number;
  duration_seconds: number;
  completed: boolean;
  liked: boolean;
  skipped: boolean;
  replays: number;
  timestamp?: number;
}
