import { Reel, TechReel, RecommendationResponse, WatchFeedbackPayload } from '../types';
import { DAILY_TECH_REELS_POOL } from '../data/demoReels';

// Deterministic semantic tag weight matrix for client-side inference
const TAG_WEIGHT_MATRIX: Record<string, Record<string, number>> = {
  java: { Java: 3.5, HLD: 0.8, Compilers: 0.5 },
  oop: { Java: 2.5, HLD: 1.0 },
  memory: { Java: 2.5, Hardware: 3.0, Compilers: 1.5 },
  "garbage-collector": { Java: 3.8, Hardware: 2.0 },
  dsa: { DSA: 3.5 },
  leetcode: { DSA: 3.0 },
  algorithms: { DSA: 3.5, AI: 1.0 },
  "dynamic-programming": { DSA: 3.5 },
  interview: { DSA: 1.8, Java: 1.0, HLD: 1.0 },
  hardware: { Hardware: 3.5, Compilers: 1.5 },
  specs: { Hardware: 1.5 },
  compiler: { Compilers: 3.5, Hardware: 2.5, Java: 1.5 },
  "cpu-benchmarks": { Hardware: 3.2 },
  macbook: { Hardware: 1.0 },
  rust: { Compilers: 3.0, Hardware: 2.0, DSA: 1.0 },
  "systems-programming": { Compilers: 3.0, Hardware: 2.5 },
  database: { HLD: 3.0, Cybersecurity: 1.0 },
  sql: { HLD: 2.5, Cybersecurity: 2.0 },
  postgresql: { HLD: 3.0 },
  deadlock: { HLD: 2.5, Java: 2.0 },
  concurrency: { Java: 2.5, HLD: 2.5 },
  ai: { AI: 3.0 },
  transformers: { AI: 3.5 },
  "deep-learning": { AI: 3.0 },
  cloud: { Cloud: 3.0, HLD: 1.5 },
  aws: { Cloud: 3.0 },
  lambda: { Cloud: 3.0, HLD: 1.5 },
  serverless: { Cloud: 3.0 },
  security: { Cybersecurity: 3.5 },
  "sql-injection": { Cybersecurity: 3.5 },
  jwt: { Cybersecurity: 3.0 },
  clickbait: { AI: -2.0, Career: -2.0 },
  "no-code": { AI: -2.5, Career: -2.0 },
  hype: { Career: -1.5, AI: -1.5 }
};

/**
 * Client-side Inference Engine
 * Analyzes selected user reels, penalizes skipped distraction traps,
 * and surfaces foundational academic CS recommendations from the daily pool.
 */
export function runClientRecommendation(
  userHistory: Reel[],
  selectedReelIds: string[],
  watchedIds: string[] = [],
  day: string = 'today'
): RecommendationResponse {
  // 1. Filter to selected reels if specified
  const activeHistory =
    selectedReelIds && selectedReelIds.length > 0
      ? userHistory.filter((r) => selectedReelIds.includes(r.id))
      : userHistory;

  const historyToAnalyze = activeHistory.length > 0 ? activeHistory : userHistory;

  // 2. Score academic categories
  const categoryScores: Record<string, number> = {
    Java: 0,
    DSA: 0,
    Hardware: 0,
    HLD: 0,
    Cybersecurity: 0,
    Cloud: 0,
    AI: 0,
    Compilers: 0
  };

  const negativeSignalsFiltered: string[] = [];
  let totalWatchPct = 0;
  let likesCount = 0;
  let skipsCount = 0;
  let replaysCount = 0;

  for (const reel of historyToAnalyze) {
    const watchPct = reel.watch_time_percentage || 0;
    const engagement = reel.engagement || 'none';
    const replays = reel.replays || 0;
    totalWatchPct += watchPct;
    if (engagement === 'liked') likesCount++;
    if (engagement === 'skipped') skipsCount++;
    replaysCount += replays;

    // Dampen formats to bypass distraction traps (memes/lifestyle/hype)
    let formatDampener = 1.0;
    if (reel.category === 'Meme' || reel.category === 'Lifestyle') {
      formatDampener = 0.40;
    } else if (reel.category === 'Hardware-Spec') {
      formatDampener = 0.55;
    } else if (reel.category === 'Hype') {
      formatDampener = 0.20;
    }

    // Engagement weights
    let engagementMultiplier = watchPct;
    if (engagement === 'liked') engagementMultiplier += 0.6;
    if (engagement === 'saved') engagementMultiplier += 0.8;
    if (engagement === 'commented') engagementMultiplier += 0.5;
    if (replays > 0) engagementMultiplier += replays * 0.4;

    // Negative penalty for skipped content
    if (engagement === 'skipped' || watchPct < 0.35) {
      engagementMultiplier -= 1.2;
      negativeSignalsFiltered.push(`${reel.title} (${reel.category})`);
    }

    for (const tag of reel.tags || []) {
      const tagLower = tag.toLowerCase();
      if (TAG_WEIGHT_MATRIX[tagLower]) {
        for (const [targetCat, weight] of Object.entries(TAG_WEIGHT_MATRIX[tagLower])) {
          if (targetCat in categoryScores) {
            categoryScores[targetCat] += weight * engagementMultiplier * formatDampener;
          }
        }
      }
    }
  }

  // 3. Determine best category
  const sortedCategories = Object.entries(categoryScores).sort((a, b) => b[1] - a[1]);
  let bestCategory = sortedCategories[0]?.[0] || 'Java';

  // 4. Retrieve candidate tech reels from daily pool
  const targetDay = day || 'today';
  const availablePool = DAILY_TECH_REELS_POOL.filter(
    (r) => r.day === targetDay || targetDay === 'all'
  );
  const poolToUse = availablePool.length > 0 ? availablePool : DAILY_TECH_REELS_POOL;

  // Filter out already watched reels
  let candidates = poolToUse.filter(
    (r) => r.category === bestCategory && !watchedIds.includes(r.id)
  );

  if (candidates.length === 0) {
    // Try second best category
    for (const [cat] of sortedCategories) {
      const fallback = poolToUse.filter(
        (r) => r.category === cat && !watchedIds.includes(r.id)
      );
      if (fallback.length > 0) {
        candidates = fallback;
        bestCategory = cat;
        break;
      }
    }
  }

  if (candidates.length === 0) {
    // Pick any unwatched reel in pool
    candidates = poolToUse.filter((r) => !watchedIds.includes(r.id));
    if (candidates.length === 0) {
      candidates = poolToUse;
    }
    if (candidates.length > 0) {
      bestCategory = candidates[0].category;
    }
  }

  const selectedReel = candidates[0] || poolToUse[0];
  const topScore = categoryScores[bestCategory] || 0;
  const confidence = topScore > 4.5 ? 'High' : topScore > 1.8 ? 'Medium' : 'Low';

  const lastActiveReel = historyToAnalyze[historyToAnalyze.length - 1]?.title || 'Meme Distraction Stream';

  // Dynamic explanation strings
  let interestDetected = `Foundational CS: ${bestCategory}`;
  let whyInferred = `Analyzed watch metrics and engagement patterns, filtering out shallow meme formats to surface deep interest in ${bestCategory}.`;
  let whyEdu = `Provides verified academic concepts in ${bestCategory} to redirect passive screen time into mastery.`;

  if (bestCategory === 'Java') {
    interestDetected = 'JVM Internals, Memory Management & Garbage Collection';
    whyInferred =
      "The student repeatedly engaged with Java GC memes, C++ pointer comparisons, and high compilation watch times. By dampening superficial meme noise and penalizing skipped clickbait, the engine extracted core signals ('java', 'memory', 'garbage-collector') and surfaced a high technical affinity for JVM runtime execution.";
    whyEdu =
      'Replaces shallow developer jokes with a rigorous architectural breakdown of JVM Stack vs. Heap allocation, GC roots, and object lifetime stages.';
  } else if (bestCategory === 'DSA') {
    interestDetected = 'Algorithmic Problem Solving & Collision Handling';
    whyInferred =
      'High watch time and likes on LeetCode/Dynamic Programming memes revealed latent focus on coding interview mechanics and computational complexity, despite being cloaked in humor.';
    whyEdu =
      'Connects the meme’s underlying algorithm struggle with an intuitive visualization of HashMap hashing math and Red-Black tree bucket conversions.';
  } else if (bestCategory === 'Hardware') {
    interestDetected = 'Computer Architecture & CPU Cache Hierarchy';
    whyInferred =
      'Engaged deeply with CPU benchmark and compiler execution speeds while skipping generic aesthetic desk tours, signaling genuine curiosity about low-level hardware performance.';
    whyEdu =
      'Explains why L1/L2 caches operate in nanoseconds compared to main DRAM, turning consumer laptop fascination into core systems architecture knowledge.';
  } else if (bestCategory === 'HLD') {
    interestDetected = 'Distributed Systems, Database Concurrency & Sharding';
    whyInferred =
      'High engagement with production PostgreSQL deadlock memes indicated interest in database architecture and backend concurrency at scale.';
    whyEdu =
      'Provides clear system design patterns for horizontal sharding, partition keys, and deadlock resolution in high-throughput database clusters.';
  } else if (bestCategory === 'Compilers') {
    interestDetected = 'Compiler Pipeline & Systems Programming';
    whyInferred =
      'Strong retention on systems programming and intern compiler stories, paired with skipped hype content, indicated interest in low-level language tools.';
    whyEdu =
      'Walks through the AST pipeline and semantic parsing passes from source code to executable bytecode.';
  } else if (bestCategory === 'Cybersecurity') {
    interestDetected = 'Application Security & Vulnerability Analysis';
    whyInferred =
      'Backend database interaction points to interest in securing query parameters and API authentication mechanisms.';
    whyEdu =
      'Deconstructs SQL injection attack vectors and demonstrates parameterized prepared statements.';
  } else if (bestCategory === 'Cloud') {
    interestDetected = 'Serverless Infrastructure & Cloud Architecture';
    whyInferred =
      'Telemetry shows engagement in distributed workflows, pointing to modern cloud execution models.';
    whyEdu =
      'Demystifies serverless microVM container initialization and cold start mitigation techniques.';
  } else if (bestCategory === 'AI') {
    interestDetected = 'Neural Networks & Deep Learning Foundations';
    whyInferred =
      "Filtered out surface-level 'no-code' AI hype while preserving semantic interest in transformer architectures.";
    whyEdu =
      'Visualizes Query/Key/Value self-attention mechanisms with mathematical clarity.';
  }

  return {
    'CURRENT REEL': lastActiveReel,
    'INTEREST DETECTED': interestDetected,
    'WHY': whyInferred,
    'RECOMMENDED TECH REEL': selectedReel.title,
    'CATEGORY': selectedReel.category,
    'WHY THIS RECOMMENDATION': whyEdu,
    'DIFFICULTY': selectedReel.difficulty,
    'CONFIDENCE': confidence,
    recommendation_id: selectedReel.id,
    recommended_reel: selectedReel,
    negative_signals_filtered: negativeSignalsFiltered,
    metrics_analyzed: {
      total_reels: historyToAnalyze.length,
      avg_watch_time: historyToAnalyze.length
        ? Math.round((totalWatchPct / historyToAnalyze.length) * 100)
        : 0,
      likes_count: likesCount,
      skips_count: skipsCount,
      replays_count: replaysCount
    }
  };
}
