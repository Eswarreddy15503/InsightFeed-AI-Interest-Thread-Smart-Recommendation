import { Reel, TechReel } from '../types';

export const INITIAL_8_DEMO_REELS: Reel[] = [
  {
    id: "history_1",
    title: "Java Garbage Collector Meme: C++ Pointers vs. JVM sweep",
    category: "Meme",
    tags: ["java", "oop", "memory", "garbage-collector", "joke"],
    watch_time_percentage: 0.95,
    engagement: "liked",
    duration_seconds: 45,
    replays: 2,
    thumbnail_description: "A distracted boyfriend meme where the guy is looking at JVM's GC while holding C++ pointer's hand.",
    channel_name: "CodeHumorLabs",
    views: "1.2M"
  },
  {
    id: "history_2",
    title: "Day in the Life of a FAANG SWE: $400k salary and free lattes",
    category: "Lifestyle",
    tags: ["career", "lifestyle", "vlog", "faang", "office"],
    watch_time_percentage: 0.70,
    engagement: "saved",
    duration_seconds: 60,
    replays: 0,
    thumbnail_description: "Vlogger showing a fancy latte and glass office walls with skyline view.",
    channel_name: "TechNomadVlogs",
    views: "890K"
  },
  {
    id: "history_3",
    title: "LeetCode Dynamic Programming vs. Simple For-Loop Interview Meme",
    category: "Meme",
    tags: ["dsa", "leetcode", "algorithms", "interview", "dynamic-programming"],
    watch_time_percentage: 0.90,
    engagement: "liked",
    duration_seconds: 30,
    replays: 1,
    thumbnail_description: "Crying Wojak trying to write DP vs Chad engineer writing a double nested loop.",
    channel_name: "ByteBanter",
    views: "2.4M"
  },
  {
    id: "history_4",
    title: "M3 Max vs. Intel Core i9 Compilation Speeds: Which is faster?",
    category: "Hardware-Spec",
    tags: ["hardware", "specs", "compiler", "macbook", "cpu-benchmarks"],
    watch_time_percentage: 0.85,
    engagement: "commented",
    duration_seconds: 55,
    replays: 1,
    thumbnail_description: "A close-up of a sleek laptop with a benchmark graph showing bar charts.",
    channel_name: "SiliconBenchmarks",
    views: "450K"
  },
  {
    id: "history_5",
    title: "10 AI Tools that get you a tech job in 2026! (NO CODING REQUIRED)",
    category: "Hype",
    tags: ["ai", "hype", "tools", "career", "clickbait", "no-code"],
    watch_time_percentage: 0.20,
    engagement: "skipped",
    duration_seconds: 50,
    replays: 0,
    thumbnail_description: "Hype-man pointing at logos of shiny AI websites with red arrows and shock face.",
    channel_name: "InstantTechWealth",
    views: "3.1M"
  },
  {
    id: "history_6",
    title: "How I built a compiler in Rust as an intern",
    category: "Career",
    tags: ["career", "rust", "compiler", "systems-programming", "internship"],
    watch_time_percentage: 0.80,
    engagement: "none",
    duration_seconds: 40,
    replays: 0,
    thumbnail_description: "Code IDE showing compiler syntax parser and AST graph.",
    channel_name: "DevJourneys",
    views: "180K"
  },
  {
    id: "history_7",
    title: "POV: Production DB Crashes at 5 PM on Friday (Postgres Deadlock Meme)",
    category: "Meme",
    tags: ["database", "sql", "postgresql", "concurrency", "deadlock", "meme"],
    watch_time_percentage: 0.88,
    engagement: "liked",
    duration_seconds: 35,
    replays: 2,
    thumbnail_description: "Dramatic movie explosion scene over a terminal throwing SQLSTATE 40P01 deadlock errors.",
    channel_name: "BackendHorrorStories",
    views: "1.8M"
  },
  {
    id: "history_8",
    title: "Overkill $10k Desk Setup for Typing 2 Lines of CSS",
    category: "Lifestyle",
    tags: ["lifestyle", "setup", "rgb", "desk", "minimalist"],
    watch_time_percentage: 0.40,
    engagement: "skipped",
    duration_seconds: 45,
    replays: 0,
    thumbnail_description: "Dark room illuminated in neon RGB showing a 49-inch curved monitor.",
    channel_name: "AestheticCode",
    views: "950K"
  }
];

export const DAILY_TECH_REELS_POOL: TechReel[] = [
  // Day 1 (Today)
  {
    id: "edu_java_1",
    title: "JVM Memory Architecture: How the Stack and Heap Work",
    category: "Java",
    tags: ["java", "jvm", "memory", "allocation", "garbage-collection"],
    difficulty: "Intermediate",
    description: "Deep dive into the Java Virtual Machine heap layout (Young Gen, Eden, Survivor, Old Gen), garbage collection roots, and stack frame memory allocation.",
    url: "https://www.youtube.com/shorts/jvm-memory-deep-dive",
    duration_seconds: 60,
    day: "today",
    code_snippet: `// Heap vs Stack in JVM
public void processUser() {
    User u = new User("Alice"); // 'u' ref on Stack, object on Heap
    int id = 101;               // Primitive stored directly on Stack
}`,
    key_takeaway: "Stack stores primitive values & thread-local execution frames; Heap stores dynamically allocated objects managed by JVM GC.",
    instructor: "Dr. Elena Rostova, Systems Engineering"
  },
  {
    id: "edu_dsa_1",
    title: "Why HashMaps are O(1) Average Time: Handling Collisions",
    category: "DSA",
    tags: ["dsa", "hashmap", "collision", "algorithms", "data-structures"],
    difficulty: "Intermediate",
    description: "Explains array hashing, bucket indexing with bitwise AND, collision resolution via chaining, and Java 8+'s automatic conversion to Red-Black trees at threshold 8.",
    url: "https://www.youtube.com/shorts/hashmap-collisions-explained",
    duration_seconds: 55,
    day: "today",
    code_snippet: `// Java HashMap Bucket Index Calculation
int hash = (key == null) ? 0 : (h = key.hashCode()) ^ (h >>> 16);
int index = (n - 1) & hash; // n is capacity power of 2`,
    key_takeaway: "Bitwise indexing (n-1 & hash) avoids slow modulo operations, and treeifying bucket collisions keeps worst-case at O(log N).",
    instructor: "Prof. Arvind Kumar, Algorithms Faculty"
  },
  {
    id: "edu_hld_1",
    title: "System Design: Scaling Databases using Sharding vs. Partitioning",
    category: "HLD",
    tags: ["system-design", "hld", "database", "scaling", "distributed-systems"],
    difficulty: "Advanced",
    description: "Visualizing horizontal sharding across physical database clusters, hash-based partitioning keys, and managing cross-shard distributed transactions.",
    url: "https://www.youtube.com/shorts/db-sharding-vs-partitioning",
    duration_seconds: 65,
    day: "today",
    code_snippet: `// Consistent Hashing Ring Logic
shardId = hash(userId) % totalShards;
// Sharding isolates write bottlenecks across physical nodes`,
    key_takeaway: "Vertical partitioning splits tables by column groups; Horizontal sharding distributes row ranges across independent database servers.",
    instructor: "Marcus Vance, Principal Infrastructure Architect"
  },
  {
    id: "edu_hardware_1",
    title: "CPU Cache Hierarchy: Why L1/L2 Caches Prevent RAM Bottlenecks",
    category: "Hardware",
    tags: ["hardware", "cpu", "cache", "performance", "architecture"],
    difficulty: "Advanced",
    description: "Why cache misses hurt execution speeds (~100x slower) and how spatial & temporal locality allows compiler code generation to execute in nanoseconds.",
    url: "https://www.youtube.com/shorts/cpu-cache-hierarchy",
    duration_seconds: 50,
    day: "today",
    code_snippet: `// Cache friendly row-major matrix traversal
for (int i = 0; i < N; i++)
  for (int j = 0; j < N; j++)
    sum += matrix[i][j]; // Sequential memory fetch hit in L1!`,
    key_takeaway: "L1 Cache hits take ~1ns (4 cycles), while main DRAM access takes ~100ns (200+ cycles). Memory layout dictates performance.",
    instructor: "Sarah Jenkins, Hardware Architecture Lab"
  },
  {
    id: "edu_cybersecurity_1",
    title: "Anatomy of an SQL Injection Attack & Prepared Statements",
    category: "Cybersecurity",
    tags: ["security", "sql-injection", "prepared-statements", "backend", "cybersecurity"],
    difficulty: "Intermediate",
    description: "Step-by-step breakdown of SQLi exploits via raw string concatenation and how pre-compiled parameterized queries separate executable code from data.",
    url: "https://www.youtube.com/shorts/preventing-sqli-properly",
    duration_seconds: 48,
    day: "today",
    code_snippet: `// Safe Parameterized Query
PreparedStatement stmt = conn.prepareStatement("SELECT * FROM users WHERE email = ?");
stmt.setString(1, userEmailInput); // Escaped & compiled AST`,
    key_takeaway: "Prepared statements pre-compile the SQL execution plan before binding parameters, rendering injected SQL syntax inert.",
    instructor: "Alex Chen, Security Research Group"
  },
  {
    id: "edu_cloud_1",
    title: "AWS Lambda Lifecycle: What Happens During a Cold Start",
    category: "Cloud",
    tags: ["cloud", "serverless", "aws", "lambda", "microservices"],
    difficulty: "Intermediate",
    description: "Exploring container provisioning, MicroVM virtualization (Firecracker), runtime bootstrapping, and memory allocation optimization in serverless backends.",
    url: "https://www.youtube.com/shorts/aws-lambda-cold-starts",
    duration_seconds: 58,
    day: "today",
    code_snippet: `// Warm execution reuse
const client = new DynamoDBClient(); // Initialized outside handler
export const handler = async (event) => {
  return await client.send(...); // Reuses existing connection
};`,
    key_takeaway: "Cold starts execute initialization code outside the handler once per container instance; warm invocations execute immediately.",
    instructor: "Priya Sharma, Cloud Solutions Fellow"
  },
  {
    id: "edu_ai_1",
    title: "Inside Transformers: How Self-Attention Focuses on Tokens",
    category: "AI",
    tags: ["ai", "transformers", "self-attention", "llm", "deep-learning"],
    difficulty: "Advanced",
    description: "Visualizing Query, Key, and Value matrices, scaled dot-product attention calculation, and multi-head representation in transformer models.",
    url: "https://www.youtube.com/shorts/transformers-self-attention",
    duration_seconds: 70,
    day: "today",
    code_snippet: `// Scaled Dot-Product Attention Formula
Attention(Q, K, V) = softmax( (Q * K^T) / sqrt(d_k) ) * V
// Computes dynamic token-to-token importance weights`,
    key_takeaway: "Self-attention replaces sequential RNN recurrence with parallel matrix multiplications, mapping contextual relationships across sequence tokens.",
    instructor: "Dr. Kenji Sato, Neural Computing Lab"
  },

  // Day 2 (Tomorrow's Feed Pool)
  {
    id: "edu_dsa_2",
    title: "Graph Traversal Masterclass: BFS Shortest Path vs DFS Backtracking",
    category: "DSA",
    tags: ["dsa", "graphs", "bfs", "dfs", "algorithms"],
    difficulty: "Intermediate",
    description: "When to choose Breadth-First Search using queues for shortest unweighted paths versus Depth-First Search with recursion for topological ordering.",
    url: "https://www.youtube.com/shorts/graph-bfs-vs-dfs",
    duration_seconds: 54,
    day: "tomorrow",
    code_snippet: `// BFS uses Queue for layer-by-layer exploration
Queue<Integer> q = new LinkedList<>();
q.add(startNode);
visited.add(startNode);`,
    key_takeaway: "BFS discovers minimum hops in unweighted graphs; DFS explores full branch paths with O(V+E) time complexity.",
    instructor: "Prof. Arvind Kumar, Algorithms Faculty"
  },
  {
    id: "edu_compilers_1",
    title: "How Abstract Syntax Trees (AST) Turn Text into Machine Code",
    category: "Compilers",
    tags: ["compilers", "rust", "ast", "lexer", "parser", "systems"],
    difficulty: "Advanced",
    description: "Follow the compiler pipeline from lexical analysis (tokenizing) to recursive descent parsing, semantic analysis, and LLVM bytecode generation.",
    url: "https://www.youtube.com/shorts/compiler-ast-pipeline",
    duration_seconds: 62,
    day: "tomorrow",
    code_snippet: `// Tokenizer -> Parser -> AST Node
enum Expr {
    Binary { op: BinOp, left: Box<Expr>, right: Box<Expr> },
    Literal(i64),
}`,
    key_takeaway: "Compilers build hierarchical syntax trees before optimization passes translate AST nodes into intermediate representations (IR).",
    instructor: "Sarah Jenkins, Hardware & Compiler Systems"
  },
  {
    id: "edu_hld_2",
    title: "Event-Driven Architecture with Kafka: Consumer Groups & Offsets",
    category: "HLD",
    tags: ["hld", "kafka", "distributed-systems", "event-driven", "messaging"],
    difficulty: "Advanced",
    description: "Understanding distributed commit logs, topic partition rebalancing, consumer offset commits, and exactly-once delivery guarantees.",
    url: "https://www.youtube.com/shorts/kafka-distributed-commit-log",
    duration_seconds: 59,
    day: "tomorrow",
    code_snippet: `// Kafka Consumer Partition Assignment
ConsumerGroup groupA -> Partition 0, Partition 1 (parallel streaming)`,
    key_takeaway: "Kafka treats topics as append-only immutable logs, allowing independent consumer groups to process events at their own pace.",
    instructor: "Marcus Vance, Principal Infrastructure Architect"
  },

  // Day 3 (Archived / Weekend Feed Pool)
  {
    id: "edu_java_2",
    title: "Java Concurrency: ReentrantLock vs Synchronized Keyword Under the Hood",
    category: "Java",
    tags: ["java", "concurrency", "multithreading", "locks", "jvm"],
    difficulty: "Advanced",
    description: "Comparing JVM monitor locks, object header lock inflation (biasing -> lightweight -> heavyweight), and AbstractQueuedSynchronizer (AQS).",
    url: "https://www.youtube.com/shorts/java-concurrency-locks",
    duration_seconds: 64,
    day: "day-3",
    code_snippet: `// Explicit lock with timeout & condition variables
ReentrantLock lock = new ReentrantLock(true); // Fair lock
if (lock.tryLock(100, TimeUnit.MILLISECONDS)) { ... }`,
    key_takeaway: "JVM intrinsic locks inflate based on thread contention; ReentrantLock provides non-blocking acquisition, fairness, and condition variables.",
    instructor: "Dr. Elena Rostova, Systems Engineering"
  },
  {
    id: "edu_cyber_2",
    title: "JWT Security Flaws: Algorithm Confusion and Token Invalidation",
    category: "Cybersecurity",
    tags: ["cybersecurity", "jwt", "auth", "tokens", "security"],
    difficulty: "Intermediate",
    description: "How 'alg: none' and asymmetric RS256 -> symmetric HS256 key confusion attacks work, plus modern blacklist and sliding refresh patterns.",
    url: "https://www.youtube.com/shorts/jwt-security-flaws",
    duration_seconds: 52,
    day: "day-3",
    code_snippet: `// Always enforce explicit verification algorithm
jwt.verify(token, publicKey, { algorithms: ['RS256'] });`,
    key_takeaway: "Always whitelist allowed signing algorithms on backend verification to prevent HMAC confusion vulnerabilities.",
    instructor: "Alex Chen, Security Research Group"
  }
];
