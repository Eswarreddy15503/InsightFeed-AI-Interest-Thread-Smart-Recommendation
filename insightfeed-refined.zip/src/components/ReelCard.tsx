import React from 'react';
import { Reel } from '../types';

interface ReelCardProps {
  reel: Reel;
  isSelected: boolean;
  onToggleSelect: (id: string) => void;
  onQuickToggleEngagement?: (id: string, newEngagement: 'liked' | 'skipped' | 'none') => void;
}

export const ReelCard: React.FC<ReelCardProps> = ({
  reel,
  isSelected,
  onToggleSelect,
  onQuickToggleEngagement,
}) => {
  const getFormatClass = (category: string) => {
    switch (category) {
      case 'Meme':
        return 'format-meme';
      case 'Lifestyle':
        return 'format-lifestyle';
      case 'Hardware-Spec':
        return 'format-spec';
      case 'Hype':
        return 'format-hype';
      case 'Career':
        return 'format-career';
      default:
        return 'format-explainer';
    }
  };

  const getEngagementBadge = (engagement: string) => {
    switch (engagement) {
      case 'liked':
        return (
          <span className="flex items-center gap-1 text-red-400 font-semibold text-xs">
            <i className="fa-solid fa-heart"></i> LIKED
          </span>
        );
      case 'saved':
        return (
          <span className="flex items-center gap-1 text-amber-300 font-semibold text-xs">
            <i className="fa-solid fa-bookmark"></i> SAVED
          </span>
        );
      case 'commented':
        return (
          <span className="flex items-center gap-1 text-blue-400 font-semibold text-xs">
            <i className="fa-solid fa-comment"></i> COMMENTED
          </span>
        );
      case 'skipped':
        return (
          <span className="flex items-center gap-1 text-zinc-400 line-through font-medium text-xs">
            <i className="fa-solid fa-forward-step text-zinc-500"></i> SKIPPED
          </span>
        );
      default:
        return (
          <span className="flex items-center gap-1 text-zinc-400 text-xs">
            <i className="fa-solid fa-eye text-zinc-500"></i> WATCHED
          </span>
        );
    }
  };

  const watchPct = Math.round((reel.watch_time_percentage || 0) * 100);

  return (
    <div
      id={`reel-card-${reel.id}`}
      onClick={() => onToggleSelect(reel.id)}
      className={`relative p-3.5 rounded-lg border transition-all cursor-pointer select-none ${
        isSelected
          ? 'bg-[rgba(88,166,255,0.06)] border-[#58a6ff]/50 shadow-[0_0_15px_rgba(88,166,255,0.12)]'
          : 'bg-white/[0.015] border-white/[0.05] hover:bg-white/[0.035] hover:border-white/[0.12]'
      }`}
    >
      {/* Top Bar with Selection Checkbox & Format */}
      <div className="flex items-start justify-between gap-2 mb-2">
        <div className="flex items-start gap-2.5 flex-1 min-w-0">
          <input
            id={`checkbox-${reel.id}`}
            type="checkbox"
            checked={isSelected}
            onChange={(e) => {
              e.stopPropagation();
              onToggleSelect(reel.id);
            }}
            className="mt-1 w-4 h-4 rounded border-gray-600 bg-gray-900 text-[#58a6ff] focus:ring-[#58a6ff] cursor-pointer"
          />
          <span className="font-semibold text-[0.93rem] text-[#f0f6fc] leading-snug break-words">
            {reel.title}
          </span>
        </div>
        <span
          className={`text-[0.7rem] px-2 py-0.5 rounded-full font-semibold uppercase shrink-0 ${getFormatClass(
            reel.category
          )}`}
        >
          {reel.category}
        </span>
      </div>

      {/* Description / Content Context */}
      <p className="text-xs text-[#8b949e] mb-2.5 line-clamp-2 pl-6.5 italic">
        "{reel.thumbnail_description}"
      </p>

      {/* Metrics Row: Watch %, Duration, Replays, Engagement */}
      <div className="flex flex-wrap items-center gap-3 text-xs text-[#8b949e] pl-6.5 mb-2">
        <span className="flex items-center gap-1.5 text-zinc-300">
          <i className="fa-solid fa-clock text-zinc-500 text-[0.75rem]"></i>
          {reel.duration_seconds}s
        </span>

        <div className="flex items-center gap-1.5">
          <span className="text-zinc-300 font-medium">{watchPct}%</span>
          <div className="w-14 h-1.5 bg-zinc-800 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full ${
                watchPct >= 80
                  ? 'bg-emerald-500'
                  : watchPct >= 50
                  ? 'bg-amber-400'
                  : 'bg-rose-500'
              }`}
              style={{ width: `${Math.min(100, Math.max(5, watchPct))}%` }}
            />
          </div>
        </div>

        {reel.replays && reel.replays > 0 ? (
          <span className="flex items-center gap-1 text-cyan-400 font-medium">
            <i className="fa-solid fa-rotate-right text-[0.7rem]"></i>
            {reel.replays}x replays
          </span>
        ) : null}

        <div className="ml-auto">{getEngagementBadge(reel.engagement)}</div>
      </div>

      {/* Tags and Quick Feedback Buttons */}
      <div className="flex items-center justify-between gap-2 pl-6.5 pt-1 border-t border-white/[0.04]">
        <div className="flex flex-wrap gap-1">
          {reel.tags.map((tag) => (
            <span
              key={tag}
              className="text-[0.68rem] bg-white/[0.04] text-[#8b949e] px-1.5 py-0.5 rounded border border-white/[0.02]"
            >
              #{tag}
            </span>
          ))}
        </div>

        {/* Optional quick toggle to test negative/positive signals */}
        {onQuickToggleEngagement && (
          <div
            className="flex items-center gap-1 shrink-0"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              id={`btn-quick-like-${reel.id}`}
              title="Toggle Liked (+ signal)"
              onClick={() =>
                onQuickToggleEngagement(
                  reel.id,
                  reel.engagement === 'liked' ? 'none' : 'liked'
                )
              }
              className={`text-[0.72rem] px-1.5 py-0.5 rounded transition ${
                reel.engagement === 'liked'
                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                  : 'text-zinc-500 hover:text-rose-400 hover:bg-white/5'
              }`}
            >
              <i className="fa-solid fa-heart"></i>
            </button>
            <button
              id={`btn-quick-skip-${reel.id}`}
              title="Toggle Skipped (- signal)"
              onClick={() =>
                onQuickToggleEngagement(
                  reel.id,
                  reel.engagement === 'skipped' ? 'none' : 'skipped'
                )
              }
              className={`text-[0.72rem] px-1.5 py-0.5 rounded transition ${
                reel.engagement === 'skipped'
                  ? 'bg-zinc-700/50 text-zinc-300 border border-zinc-600'
                  : 'text-zinc-500 hover:text-zinc-300 hover:bg-white/5'
              }`}
            >
              <i className="fa-solid fa-forward-step"></i>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
