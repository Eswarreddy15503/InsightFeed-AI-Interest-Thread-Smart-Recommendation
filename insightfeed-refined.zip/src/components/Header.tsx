import React from 'react';

interface HeaderProps {
  selectedDay: string;
  onSelectDay: (day: string) => void;
  onResetHistory: () => void;
  isResetting: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  selectedDay,
  onSelectDay,
  onResetHistory,
  isResetting,
}) => {
  return (
    <header className="w-full max-w-6xl text-center mb-6 pb-6 border-b border-[#30363d]/60">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
        <span className="text-[0.8rem] tracking-wider uppercase text-[#8b949e] font-semibold inline-flex items-center gap-1.5 bg-white/[0.04] px-3.5 py-1 rounded-full border border-dashed border-[#30363d]">
          <i className="fa-solid fa-graduation-cap text-[#58a6ff]"></i>
          CS301: AI Assignment &bull; Built by Team 4
        </span>

        {/* Daily Feed Switcher (Scalable daily recommendation system) */}
        <div className="flex items-center gap-1.5 bg-[#161b22] p-1 rounded-full border border-[#30363d] text-xs">
          <span className="text-[0.7rem] text-[#8b949e] px-2 font-medium">Daily Feed:</span>
          <button
            id="btn-feed-today"
            onClick={() => onSelectDay('today')}
            className={`px-2.5 py-1 rounded-full font-medium transition ${
              selectedDay === 'today'
                ? 'bg-[#58a6ff] text-[#0d1117] font-semibold shadow'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Today's Feed
          </button>
          <button
            id="btn-feed-tomorrow"
            onClick={() => onSelectDay('tomorrow')}
            className={`px-2.5 py-1 rounded-full font-medium transition ${
              selectedDay === 'tomorrow'
                ? 'bg-[#58a6ff] text-[#0d1117] font-semibold shadow'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Tomorrow
          </button>
          <button
            id="btn-feed-day3"
            onClick={() => onSelectDay('day-3')}
            className={`px-2.5 py-1 rounded-full font-medium transition ${
              selectedDay === 'day-3'
                ? 'bg-[#58a6ff] text-[#0d1117] font-semibold shadow'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Archive (Day 3)
          </button>
        </div>
      </div>

      <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-[#58a6ff] via-[#9b59b6] to-[#bc8cff] bg-clip-text text-transparent mb-2">
        AI-Powered Academic Recommender Agent
      </h1>
      <p className="text-[#8b949e] text-sm max-w-2xl mx-auto leading-relaxed">
        Analyzing distraction watch cycles (memes, lifestyle hype, spec benchmarks) to extract signals and surface foundational Computer Science concepts.
      </p>

      {/* Quick helper controls */}
      <div className="flex items-center justify-center gap-3 mt-3">
        <button
          id="btn-reset-history"
          onClick={onResetHistory}
          disabled={isResetting}
          className="text-xs text-gray-400 hover:text-gray-200 bg-white/5 hover:bg-white/10 px-3 py-1 rounded-full border border-white/10 transition flex items-center gap-1.5"
          title="Reset user watch history to initial 8 demo reels"
        >
          <i className={`fa-solid fa-rotate-left ${isResetting ? 'fa-spin' : ''}`}></i>
          Reset 8 Demo Reels
        </button>
      </div>
    </header>
  );
};
