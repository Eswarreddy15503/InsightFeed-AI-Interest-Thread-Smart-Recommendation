import React from 'react';
import { RecommendationResponse, TechReel } from '../types';

interface InferenceOutputProps {
  isLoading: boolean;
  result: RecommendationResponse | null;
  onOpenWatchModal: (reel?: TechReel) => void;
}

export const InferenceOutput: React.FC<InferenceOutputProps> = ({
  isLoading,
  result,
  onOpenWatchModal,
}) => {
  const getCategoryClass = (category: string) => {
    switch (category?.toLowerCase()) {
      case 'java': return 'cat-java';
      case 'dsa': return 'cat-dsa';
      case 'hardware': return 'cat-hardware';
      case 'hld': return 'cat-hld';
      case 'cybersecurity': return 'cat-cybersecurity';
      case 'cloud': return 'cat-cloud';
      case 'ai': return 'cat-ai';
      case 'compilers': return 'cat-compilers';
      default: return 'cat-dsa';
    }
  };

  const getDifficultyClass = (difficulty: string) => {
    switch (difficulty?.toLowerCase()) {
      case 'beginner': return 'diff-beginner';
      case 'intermediate': return 'diff-intermediate';
      case 'advanced': return 'diff-advanced';
      default: return 'diff-intermediate';
    }
  };

  const getConfidenceClass = (confidence: string) => {
    switch (confidence?.toLowerCase()) {
      case 'high': return 'conf-high';
      case 'medium': return 'conf-medium';
      case 'low': return 'conf-low';
      default: return 'conf-medium';
    }
  };

  return (
    <section className="glass-panel p-6 flex flex-col h-full min-h-[480px]">
      <h2 className="text-xl font-bold mb-4 flex items-center gap-2 pb-2 border-b border-white/5">
        <i className="fa-solid fa-microchip text-[#58a6ff]"></i>
        Agent Inference Outputs
      </h2>

      {isLoading ? (
        <div id="output-loading-state" className="flex flex-col items-center justify-center flex-grow py-12 text-center text-[#8b949e]">
          <div className="w-9 h-9 border-[3.5px] border-white/10 border-l-[#58a6ff] rounded-full animate-spin mb-4"></div>
          <p className="font-semibold text-white text-sm mb-1">Analyzing Distraction Watch Cycles...</p>
          <p className="text-xs text-[#8b949e] max-w-sm">
            Feeding interactions into neural category mapper &bull; stripping meme signatures &bull; filtering negative signals &bull; routing to academic database...
          </p>
        </div>
      ) : !result ? (
        <div id="output-placeholder-state" className="flex flex-col items-center justify-center flex-grow py-12 text-center text-[#8b949e]">
          <i className="fa-solid fa-brain text-5xl text-white/5 mb-4"></i>
          <p className="text-sm text-[#8b949e] max-w-sm">
            Select one or more Reels from the watch history on the left, then click <strong className="text-white font-medium">Find my thread</strong> below to extract and surface foundational Computer Science concepts.
          </p>
        </div>
      ) : (
        <div id="output-content-state" className="flex flex-col gap-4 animate-fade-in">
          {/* Analysis Metrics Pill Summary */}
          {result.metrics_analyzed && (
            <div className="flex flex-wrap items-center gap-2 p-2.5 rounded-lg bg-black/30 border border-white/5 text-[0.72rem] text-[#8b949e]">
              <span className="text-white font-semibold flex items-center gap-1">
                <i className="fa-solid fa-chart-simple text-[#58a6ff]"></i> Telemetry:
              </span>
              <span>{result.metrics_analyzed.total_reels} Reels Evaluated</span>
              <span>&bull;</span>
              <span>Avg Watch {result.metrics_analyzed.avg_watch_time}%</span>
              <span>&bull;</span>
              <span className="text-rose-400 font-medium">{result.metrics_analyzed.likes_count} Liked</span>
              <span>&bull;</span>
              <span className="text-amber-400 font-medium">{result.metrics_analyzed.skips_count} Skipped (Penalized)</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Current Reel (Distraction Source) */}
            <div className="col-span-full p-3.5 rounded-lg bg-[rgba(231,76,60,0.04)] border border-[rgba(231,76,60,0.18)]">
              <div className="text-[0.72rem] uppercase tracking-wider font-semibold text-[#e74c3c] mb-1 flex items-center gap-1.5">
                <i className="fa-solid fa-circle-play"></i> Current Reel (Distraction Source)
              </div>
              <div className="font-semibold text-sm text-white">{result["CURRENT REEL"]}</div>
            </div>

            {/* Interest Detected */}
            <div className="p-3.5 rounded-lg bg-white/[0.015] border border-white/[0.04]">
              <div className="text-[0.72rem] uppercase tracking-wider font-semibold text-[#8b949e] mb-1 flex items-center gap-1.5">
                <i className="fa-solid fa-bullseye text-[#58a6ff]"></i> Interest Detected
              </div>
              <div className="font-semibold text-sm text-[#58a6ff] leading-snug">
                {result["INTEREST DETECTED"]}
              </div>
            </div>

            {/* Confidence */}
            <div className="p-3.5 rounded-lg bg-white/[0.015] border border-white/[0.04]">
              <div className="text-[0.72rem] uppercase tracking-wider font-semibold text-[#8b949e] mb-1 flex items-center gap-1.5">
                <i className="fa-solid fa-chart-bar text-[#58a6ff]"></i> Confidence Level
              </div>
              <div className="mt-1">
                <span className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-semibold uppercase tracking-wider ${getConfidenceClass(result["CONFIDENCE"])}`}>
                  {result["CONFIDENCE"]}
                </span>
              </div>
            </div>

            {/* Why This Interest Was Inferred */}
            <div className="col-span-full p-3.5 rounded-lg bg-white/[0.015] border border-white/[0.04]">
              <div className="text-[0.72rem] uppercase tracking-wider font-semibold text-[#8b949e] mb-1 flex items-center gap-1.5">
                <i className="fa-solid fa-circle-info text-[#58a6ff]"></i> Why this interest was inferred
              </div>
              <p className="text-xs text-[#8b949e] leading-relaxed">
                {result["WHY"]}
              </p>
            </div>

            {/* Recommended Tech Reel Banner */}
            <div className="col-span-full p-4 rounded-lg bg-gradient-to-br from-[rgba(88,166,255,0.08)] to-[rgba(188,140,255,0.08)] border border-[rgba(88,166,255,0.2)]">
              <div className="text-[0.72rem] uppercase tracking-wider font-semibold text-[#2ecc71] mb-2 flex items-center gap-1.5">
                <i className="fa-solid fa-star"></i> Recommended Tech Reel
              </div>

              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-base font-bold text-white mb-1.5">
                    {result["RECOMMENDED TECH REEL"]}
                  </h4>
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className={`px-2.5 py-0.5 rounded-full text-[0.72rem] font-semibold uppercase tracking-wider ${getCategoryClass(result["CATEGORY"])}`}>
                      {result["CATEGORY"]}
                    </span>
                    <span className={`px-2.5 py-0.5 rounded-full text-[0.72rem] font-semibold uppercase tracking-wider ${getDifficultyClass(result["DIFFICULTY"])}`}>
                      {result["DIFFICULTY"]}
                    </span>
                  </div>
                </div>

                {/* Working Watch Reel Action Button */}
                <button
                  id="btn-watch-recommended-reel"
                  onClick={() => onOpenWatchModal(result.recommended_reel)}
                  className="px-4 py-2 rounded-full bg-white hover:bg-[#e1e1e1] text-[#0d1117] font-semibold text-xs transition transform hover:scale-105 shadow-md flex items-center gap-1.5 shrink-0"
                >
                  <i className="fa-solid fa-play text-xs text-[#0d1117]"></i>
                  Watch Reel
                </button>
              </div>
            </div>

            {/* Why Recommendation is Educational */}
            <div className="col-span-full p-3.5 rounded-lg bg-white/[0.015] border border-white/[0.04]">
              <div className="text-[0.72rem] uppercase tracking-wider font-semibold text-[#8b949e] mb-1 flex items-center gap-1.5">
                <i className="fa-solid fa-graduation-cap text-[#58a6ff]"></i> Why this recommendation is educational
              </div>
              <p className="text-xs text-[#8b949e] leading-relaxed">
                {result["WHY THIS RECOMMENDATION"]}
              </p>
            </div>

            {/* Negative Signals Filtered Notice */}
            {result.negative_signals_filtered && result.negative_signals_filtered.length > 0 && (
              <div className="col-span-full p-3 rounded-lg bg-amber-950/20 border border-amber-500/20 text-[0.72rem] text-amber-200/90 leading-relaxed">
                <span className="font-semibold flex items-center gap-1 text-amber-400 mb-0.5">
                  <i className="fa-solid fa-filter"></i> Distraction Signals Penalized:
                </span>
                Ignored shallow hype &amp; low-retention videos ({result.negative_signals_filtered.join(', ')}) to prevent recommending low-value clickbait.
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
