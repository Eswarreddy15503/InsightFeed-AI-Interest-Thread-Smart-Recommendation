import React, { useState, useEffect, useRef } from 'react';
import { TechReel, WatchFeedbackPayload } from '../types';

interface VideoModalProps {
  reel: TechReel | null;
  isOpen: boolean;
  onClose: () => void;
  onFeedbackSubmitted: (feedback: WatchFeedbackPayload) => void;
}

export const VideoModal: React.FC<VideoModalProps> = ({
  reel,
  isOpen,
  onClose,
  onFeedbackSubmitted,
}) => {
  if (!isOpen || !reel) return null;

  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(reel.duration_seconds || 60);
  const [isLiked, setIsLiked] = useState<boolean>(false);
  const [isSkipped, setIsSkipped] = useState<boolean>(false);
  const [replays, setReplays] = useState<number>(0);
  const [activeTab, setActiveTab] = useState<'visual' | 'code' | 'notes'>('visual');
  const [feedbackSent, setFeedbackSent] = useState<boolean>(false);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Playback timer simulation
  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= duration) {
            setIsPlaying(false);
            return duration;
          }
          return prev + 1;
        });
      }, 1000);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, duration]);

  const watchPercentage = Math.min(1, currentTime / (duration || 60));
  const isCompleted = currentTime >= duration;

  const handleTogglePlay = () => {
    if (isCompleted) {
      setCurrentTime(0);
      setReplays((prev) => prev + 1);
      setIsPlaying(true);
    } else {
      setIsPlaying(!isPlaying);
    }
  };

  const handleReplay = () => {
    setCurrentTime(0);
    setReplays((prev) => prev + 1);
    setIsPlaying(true);
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
  };

  const handleSkip = () => {
    setIsSkipped(true);
    setIsPlaying(false);
    sendFeedback(true, isLiked, watchPercentage, false);
  };

  const handleFinishAndSave = () => {
    sendFeedback(false, isLiked, 1.0, true);
  };

  const sendFeedback = (
    skipped: boolean,
    liked: boolean,
    watchPct: number,
    completed: boolean
  ) => {
    const payload: WatchFeedbackPayload = {
      reel_id: reel.id,
      reel_title: reel.title,
      category: reel.category,
      watch_percentage: parseFloat(watchPct.toFixed(2)),
      duration_seconds: duration,
      completed,
      liked,
      skipped,
      replays,
      timestamp: Date.now(),
    };

    setFeedbackSent(true);
    onFeedbackSubmitted(payload);
  };

  // Format MM:SS
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainingSecs = Math.floor(secs % 60);
    return `${mins}:${remainingSecs < 10 ? '0' : ''}${remainingSecs}`;
  };

  return (
    <div
      id="video-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in"
      onClick={onClose}
    >
      <div
        id="video-modal-container"
        className="relative w-full max-w-3xl bg-[#161b22] border border-[#30363d] rounded-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          id="btn-close-modal"
          onClick={onClose}
          className="absolute top-3 right-3 z-20 w-8 h-8 rounded-full bg-black/60 hover:bg-black text-gray-300 hover:text-white flex items-center justify-center transition"
        >
          <i className="fa-solid fa-xmark"></i>
        </button>

        {/* Left / Top: Interactive Player Screen */}
        <div className="w-full md:w-1/2 bg-[#090d13] flex flex-col items-center justify-between p-4 relative border-b md:border-b-0 md:border-r border-[#30363d]">
          {/* Top category / Instructor banner */}
          <div className="w-full flex items-center justify-between mb-2">
            <span className={`text-[0.7rem] font-bold uppercase px-2.5 py-0.5 rounded-full cat-${reel.category.toLowerCase()}`}>
              <i className="fa-solid fa-graduation-cap mr-1"></i> {reel.category}
            </span>
            <span className={`text-[0.7rem] font-bold uppercase px-2 py-0.5 rounded-full diff-${reel.difficulty.toLowerCase()}`}>
              {reel.difficulty}
            </span>
          </div>

          {/* Animated Tech Visual Stage */}
          <div className="w-full h-56 md:h-64 rounded-xl bg-gradient-to-br from-[#121820] to-[#1c2430] border border-white/5 relative overflow-hidden flex flex-col items-center justify-center p-4 text-center">
            {/* Visual background pulse effect */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(88,166,255,0.15),transparent_70%)]"></div>

            {/* Dynamic visual representations by Category */}
            {reel.category === 'Java' && (
              <div className="z-10 flex flex-col items-center gap-2">
                <div className="flex gap-3">
                  <div className="w-18 py-2 bg-blue-950/70 border border-blue-500/40 rounded-lg text-center">
                    <span className="text-[0.65rem] text-blue-400 font-bold block">STACK</span>
                    <span className="text-[0.6rem] text-gray-300">Frames (1MB)</span>
                  </div>
                  <div className="w-24 py-2 bg-emerald-950/70 border border-emerald-500/40 rounded-lg text-center">
                    <span className="text-[0.65rem] text-emerald-400 font-bold block">HEAP</span>
                    <span className="text-[0.6rem] text-gray-300">GC Young/Old</span>
                  </div>
                </div>
                <p className="text-[0.72rem] text-gray-400 font-mono mt-1">JVM Pointer De-reference OK</p>
              </div>
            )}

            {reel.category === 'DSA' && (
              <div className="z-10 flex flex-col items-center gap-2">
                <div className="flex items-center gap-1.5 font-mono text-xs">
                  <span className="p-1.5 bg-emerald-900/50 border border-emerald-500 rounded text-emerald-300">hash(key)</span>
                  <span className="text-gray-500">&rarr;</span>
                  <span className="p-1.5 bg-purple-900/50 border border-purple-500 rounded text-purple-300">Bucket [3]</span>
                  <span className="text-gray-500">&rarr;</span>
                  <span className="p-1.5 bg-amber-900/50 border border-amber-500 rounded text-amber-300">O(1)</span>
                </div>
                <p className="text-[0.72rem] text-emerald-400 font-mono">Red-Black Tree Collision Threshold = 8</p>
              </div>
            )}

            {reel.category === 'Hardware' && (
              <div className="z-10 flex flex-col items-center gap-2">
                <div className="flex flex-col gap-1 w-36">
                  <div className="bg-red-950/60 border border-red-500/40 py-1 rounded text-center text-[0.68rem] text-red-300 font-bold">L1 Cache (~1ns)</div>
                  <div className="bg-amber-950/60 border border-amber-500/40 py-1 rounded text-center text-[0.68rem] text-amber-300 font-bold">L2 Cache (~4ns)</div>
                  <div className="bg-blue-950/60 border border-blue-500/40 py-1 rounded text-center text-[0.68rem] text-blue-300 font-bold">Main DRAM (~100ns)</div>
                </div>
              </div>
            )}

            {reel.category === 'HLD' && (
              <div className="z-10 flex flex-col items-center gap-2">
                <div className="flex gap-2">
                  <div className="p-2 bg-teal-950/60 border border-teal-500/40 rounded text-center text-[0.68rem] text-teal-300">
                    <i className="fa-solid fa-server block mb-1"></i> Shard 01 (A-M)
                  </div>
                  <div className="p-2 bg-teal-950/60 border border-teal-500/40 rounded text-center text-[0.68rem] text-teal-300">
                    <i className="fa-solid fa-server block mb-1"></i> Shard 02 (N-Z)
                  </div>
                </div>
              </div>
            )}

            {!['Java', 'DSA', 'Hardware', 'HLD'].includes(reel.category) && (
              <div className="z-10 flex flex-col items-center gap-2">
                <i className="fa-solid fa-microchip text-3xl text-[#58a6ff] mb-1"></i>
                <span className="text-sm font-semibold text-white">{reel.category} Concept Lab</span>
                <span className="text-xs text-gray-400 font-mono">{reel.tags.join(' • ')}</span>
              </div>
            )}

            {/* Play/Pause Overlay Icon */}
            <button
              id="btn-play-pause-overlay"
              onClick={handleTogglePlay}
              className="mt-3 z-10 w-10 h-10 rounded-full bg-[#58a6ff]/90 hover:bg-[#58a6ff] text-[#0d1117] flex items-center justify-center shadow-lg transition"
            >
              <i className={`fa-solid ${isPlaying ? 'fa-pause' : 'fa-play'}`}></i>
            </button>
          </div>

          {/* Progress Bar & Video Control Strip */}
          <div className="w-full mt-3">
            <div className="flex items-center justify-between text-[0.75rem] text-gray-400 mb-1">
              <span>{formatTime(currentTime)}</span>
              <span className="text-[#58a6ff] font-semibold">{Math.round(watchPercentage * 100)}% Watched</span>
              <span>{formatTime(duration)}</span>
            </div>

            {/* Interactive scrub progress */}
            <div
              className="w-full h-2 bg-gray-800 rounded-full overflow-hidden cursor-pointer relative"
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const clickPos = (e.clientX - rect.left) / rect.width;
                setCurrentTime(Math.floor(clickPos * duration));
              }}
            >
              <div
                className="h-full bg-gradient-to-r from-[#58a6ff] to-[#bc8cff] transition-all duration-200"
                style={{ width: `${watchPercentage * 100}%` }}
              />
            </div>

            {/* Live Feedback Action Bar */}
            <div className="flex items-center justify-between mt-3 pt-2 border-t border-white/5">
              <div className="flex items-center gap-2">
                {/* Like Button */}
                <button
                  id="btn-modal-like"
                  onClick={handleLike}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold transition ${
                    isLiked
                      ? 'bg-rose-500 text-white shadow-md shadow-rose-500/30'
                      : 'bg-white/5 text-gray-300 hover:bg-white/10 hover:text-rose-400'
                  }`}
                >
                  <i className="fa-solid fa-heart"></i>
                  {isLiked ? 'Liked' : 'Like'}
                </button>

                {/* Replay Button */}
                <button
                  id="btn-modal-replay"
                  onClick={handleReplay}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs bg-white/5 text-gray-300 hover:bg-white/10 hover:text-cyan-400 transition"
                >
                  <i className="fa-solid fa-rotate-right"></i>
                  {replays > 0 ? `${replays}x` : 'Replay'}
                </button>
              </div>

              {/* Skip Button */}
              <button
                id="btn-modal-skip"
                onClick={handleSkip}
                className="flex items-center gap-1 text-xs text-gray-400 hover:text-amber-400 transition px-2 py-1"
              >
                <i className="fa-solid fa-forward-step"></i> Skip
              </button>
            </div>
          </div>
        </div>

        {/* Right / Bottom: Educational Concept Breakdown & Feedback Tracking */}
        <div className="w-full md:w-1/2 p-5 flex flex-col justify-between overflow-y-auto">
          <div>
            {/* Header info */}
            <h3 className="text-lg font-bold text-white mb-1.5 leading-snug">
              {reel.title}
            </h3>
            <p className="text-xs text-[#8b949e] mb-4">
              Instructor: <span className="text-gray-300 font-medium">{reel.instructor || 'Academic Faculty'}</span>
            </p>

            {/* Tab navigation for educational breakdown */}
            <div className="flex gap-2 border-b border-[#30363d] pb-2 mb-3 text-xs">
              <button
                onClick={() => setActiveTab('visual')}
                className={`pb-1 px-2 font-medium transition ${
                  activeTab === 'visual'
                    ? 'text-[#58a6ff] border-b-2 border-[#58a6ff]'
                    : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                Concept
              </button>
              <button
                onClick={() => setActiveTab('code')}
                className={`pb-1 px-2 font-medium transition ${
                  activeTab === 'code'
                    ? 'text-[#58a6ff] border-b-2 border-[#58a6ff]'
                    : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                Code Snippet
              </button>
              <button
                onClick={() => setActiveTab('notes')}
                className={`pb-1 px-2 font-medium transition ${
                  activeTab === 'notes'
                    ? 'text-[#58a6ff] border-b-2 border-[#58a6ff]'
                    : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                Key Takeaway
              </button>
            </div>

            {/* Tab contents */}
            {activeTab === 'visual' && (
              <div className="text-xs text-gray-300 leading-relaxed bg-black/20 p-3 rounded-lg border border-white/5">
                <p className="mb-2">{reel.description}</p>
                <div className="flex flex-wrap gap-1 mt-2">
                  {reel.tags.map((t) => (
                    <span key={t} className="text-[0.68rem] bg-white/5 text-gray-400 px-1.5 py-0.5 rounded">
                      #{t}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'code' && (
              <div className="bg-black/40 p-3 rounded-lg border border-white/5 font-mono text-[0.72rem] text-emerald-300 overflow-x-auto whitespace-pre">
                {reel.code_snippet || '// Technical implementation preview'}
              </div>
            )}

            {activeTab === 'notes' && (
              <div className="bg-blue-950/20 border border-blue-500/20 p-3 rounded-lg text-xs text-blue-200 leading-relaxed">
                <i className="fa-solid fa-lightbulb text-amber-400 mr-1.5"></i>
                {reel.key_takeaway || 'Structured academic lesson to bypass distraction traps.'}
              </div>
            )}
          </div>

          {/* Bottom Completion & Feedback Status */}
          <div className="mt-4 pt-3 border-t border-[#30363d]">
            {feedbackSent ? (
              <div className="flex items-center justify-between text-xs text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 p-2.5 rounded-lg">
                <span className="flex items-center gap-1.5 font-medium">
                  <i className="fa-solid fa-circle-check"></i>
                  Watch telemetry saved! History updated for future threads.
                </span>
                <button
                  onClick={onClose}
                  className="px-2.5 py-1 bg-emerald-500 text-black font-semibold rounded text-[0.7rem] hover:bg-emerald-400 transition"
                >
                  Done
                </button>
              </div>
            ) : (
              <div className="flex items-center justify-between gap-3">
                <span className="text-[0.72rem] text-gray-400">
                  {isCompleted
                    ? 'Reel completed! Save to your profile.'
                    : `Watched ${formatTime(currentTime)} of ${formatTime(duration)}`}
                </span>
                <button
                  id="btn-complete-watch"
                  onClick={handleFinishAndSave}
                  className="px-4 py-2 bg-gradient-to-r from-[#58a6ff] to-[#bc8cff] hover:opacity-90 text-white font-semibold text-xs rounded-lg shadow-md transition flex items-center gap-1.5"
                >
                  <i className="fa-solid fa-check"></i>
                  Record Completed
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
